package com.example.lab1_tan;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * A simple {@link Fragment} subclass.
 * create an instance of this fragment.
 */
public class Lab1_TanHoang extends Fragment {
    ListView lv;
    TextView theTextView;
    SearchView searchView;
    ArrayAdapter<String> adapter;
    String[] data= {"AIActivity", "VRActivity"};
    @Override
    public void onStart() {
        super.onStart();
        Log.d("MainLifecycle", "The app is started");
        theTextView = (TextView) theTextView.findViewById(R.id.textView2);
        theTextView.setText("onStart excuted");

        Toast.makeText( getContext(), "MainOnStart", Toast.LENGTH_SHORT).show();
    }


    @Override
    public void onStop() {
        super.onStop();
        Log.d("MainLifecycle", "The app is stoped");
        Toast.makeText( getContext(),"MainOnStop", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("MainLifecycle", "The app is destroyed");
        Toast.makeText( getContext(),"MainOnDestroy", Toast.LENGTH_SHORT).show();
    }


    public Lab1_TanHoang(){

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_lab1__tan_hoang, container, false);
        lv = (ListView) view.findViewById(R.id.idListView);
        adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, data);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent intent = new Intent(view.getContext(), AIActivity.class);
                    startActivity(intent);
                }
                else {
                    Intent intent = new Intent(view.getContext(), VRActivity.class);
                    startActivity(intent);
                }
            }
        });
        return view;
    }
}